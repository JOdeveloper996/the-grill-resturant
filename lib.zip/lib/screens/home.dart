import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  List<dynamic> posts = []; // List to store posts fetched from API
  List<dynamic> filteredPosts = []; // List to store filtered posts
  TextEditingController searchController = TextEditingController();

  // Fetch posts from the API
  Future<void> _fetchPosts() async {
    final response =
        await http.get(Uri.parse('https://jsonplaceholder.typicode.com/posts'));
    if (response.statusCode == 200) {
      setState(() {
        posts = json.decode(response.body);
        filteredPosts = posts; // Initialize filtered posts with all posts
      });
    } else {
      // Handle API error
      throw Exception('Failed to load posts');
    }
  }

  // Filter posts based on search query
  void _filterPosts(String query) {
    setState(() {
      filteredPosts = posts
          .where((post) =>
              post['title'].toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  // Logout user
  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  void initState() {
    super.initState();
    _fetchPosts(); // Fetch posts when screen loads
    searchController.addListener(() {
      _filterPosts(searchController.text); // Filter posts as user types
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home Screen')),
      body: _selectedIndex == 0 ? _buildHomeTab() : _buildProfileTab(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  // Home Tab UI: Display posts and search bar
  Widget _buildHomeTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            controller: searchController,
            decoration: const InputDecoration(
              labelText: 'Search Posts',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.search),
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: filteredPosts.length,
            itemBuilder: (context, index) {
              return ListTile(
                title: Text(filteredPosts[index]['title']),
                subtitle: Text(filteredPosts[index]['body']),
              );
            },
          ),
        ),
      ],
    );
  }

  // Profile Tab UI: Display user data and logout button
  Widget _buildProfileTab() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return Center(child: Text('No user logged in.'));
    }

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 50,
            backgroundImage: NetworkImage(user.photoURL ??
                'https://www.w3schools.com/w3images/avatar2.png'),
          ),
          const SizedBox(height: 16),
          Text(
            'Name: ${user.displayName ?? 'N/A'}',
            style: const TextStyle(fontSize: 18),
          ),
          Text(
            'Email: ${user.email ?? 'N/A'}',
            style: const TextStyle(fontSize: 18),
          ),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: _logout,
            child: const Text('Logout'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 40),
            ),
          ),
        ],
      ),
    );
  }
}

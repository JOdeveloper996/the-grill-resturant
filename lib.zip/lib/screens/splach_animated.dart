import 'package:firebasetask/screens/login.dart';
import 'package:flutter/material.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:page_transition/page_transition.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      splashTransition: SplashTransition.rotationTransition,
      splashIconSize: 200,
      splash: const CircleAvatar(
        backgroundImage: AssetImage('lib/assets/images/resturant.jpg'),
        radius: 100,
      ),
      backgroundColor: const Color.fromARGB(255, 80, 79, 79),
      nextScreen: const LoginUsers(),
      pageTransitionType: PageTransitionType.leftToRight,
    );
  }
}

package com.example.firebasetask

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
